const verif = () =>{
    const name = document.getElementById("name").value;
    const nbCels = document.querySelector('input[name="radio"]:checked').value;
    const nameRegex = /^[A-Za-z]+$/;
    
    if(!nameRegex.test(name)){
        alert("Enter a valid name")
        return false;
    }
    return [name,nbCels]
}
const playButton = document.getElementById('btn');

playButton.addEventListener('click', () => {
    if(verif()){
        const values = verif();
        const url = `game.html?name=${values[0]}&nbCels=${values[1]}`;
        window.location.href = url;
    }else{
        window.location.reload()
    }
    
})