const params = new URLSearchParams(window.location.search);
const PlayerName = params.get("name");
const size = params.get("nbCels");

const board = document.getElementById("board");
const status = document.getElementById("status");
const reset = document.getElementById("reset");
const playerFieldName = document.getElementById("player1");
let cells = [];
let currentPlayer = "😎";
let gameOver = false;

const init = () => {
  board.innerHTML = "";
  for (let i = 0; i < size * size; i++) {
    playerFieldName.innerHTML = PlayerName;
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.setAttribute("data-index", i);
    board.style.gridTemplateColumns = `repeat(${size}, auto)`;
    cellDimentions = (board.offsetHeight / parseInt(size)) - 0.1 *size,
    cell.style.height = cellDimentions + "px";
    cell.style.width = cellDimentions + "px";
    cell.style.fontSize = cellDimentions * 0.5 + "px";
    cell.addEventListener("click", handleClick);
    board.appendChild(cell);
    cells.push("");
  }
  board.style.setProperty("--size", size);
  currentPlayer = "😎";
  gameOver = false;
};

const handleClick = (e) => {
  const cell = e.target;
  const index = cell.dataset.index;
  if (cells[index] !== "" || gameOver) {
    return;
  }
  cells[index] = currentPlayer;
  cell.innerText = currentPlayer;
  if (checkWin(cells, size)) {
    status.innerText = currentPlayer + " wins!";
    gameOver = true;
    return;
  }
  if (checkDraw()) {
    status.innerText = "Draw!";
    gameOver = true;
    return;
  }
  currentPlayer = currentPlayer === "😎" ? "👽 " : "😎";
  computerPlay();
}

const checkWin = (cells, size) => {
  const lines = [];

  for (let i = 0; i < size; i++) {
    const row = [];
    const col = [];
    for (let j = 0; j < size; j++) {
      row.push(i * size + j);
      col.push(j * size + i);
    }
    lines.push(row);
    lines.push(col);
  }

  const diagonal1 = [];
  const diagonal2 = [];
  for (let i = 0; i < size; i++) {
    diagonal1.push(i * size + i);
    diagonal2.push(i * size + (size - i - 1));
  }
  lines.push(diagonal1);
  lines.push(diagonal2);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (
      cells[line[0]] !== "" &&
      line.every((index) => cells[index] === cells[line[0]])
    ) {
      return true;
    }
  }

  return false;
}

const checkDraw = () =>{
  return cells.every((cell) => cell !== "");
}

const computerPlay = () => {
  const emptyCells = cells.reduce((acc, val, index) => {
    if (val === "") {
      acc.push(index);
    }
    return acc;
  }, []);

  for (let i = 0; i < emptyCells.length; i++) {
    const cellIndex = emptyCells[i];
    const testCells = [...cells];
    testCells[cellIndex] = currentPlayer;
    if (checkWin(testCells, size)) {
      cells[cellIndex] = currentPlayer;
      const cell = board.querySelector(`[data-index="${cellIndex}"]`);
      cell.innerText = currentPlayer;
      console.log("eeeeee",cellIndex)
      console.log("eeeeeff")
      if (checkWin(cells, size)) {
        status.innerText = currentPlayer + " wins!";
        gameOver = true;
        return;
      }
      if (checkDraw()) {
        status.innerText = "Draw!";
        gameOver = true;
        return;
      }
      currentPlayer = currentPlayer === "😎" ? "👽 " : "😎";
      return;
    }
  }

  const otherPlayer = currentPlayer === "😎" ? "👽" : "😎";
  for (let i = 0; i < emptyCells.length; i++) {
    const cellIndex = emptyCells[i];
    const testCells = [...cells];
    testCells[cellIndex] = otherPlayer;
    if (checkWin(testCells, size)) {
      cells[cellIndex] = currentPlayer;
      const cell = board.querySelector(`[data-index="${cellIndex}"]`);
      cell.innerText = currentPlayer;
      if (checkWin(cells, size)) {
        status.innerText = currentPlayer + " wins!";
        gameOver = true;
        return;
      }
      if (checkDraw()) {
        status.innerText = "Draw!";
        gameOver = true;
        return;
      }
      currentPlayer = currentPlayer === "😎" ? "👽 " : "😎";
      return;
    }
  }

  const randomIndex = Math.floor(Math.random() * emptyCells.length);
  const cellIndex = emptyCells[randomIndex];
  cells[cellIndex] = currentPlayer;
  const cell = board.querySelector(`[data-index="${cellIndex}"]`);
  cell.innerText = currentPlayer;
  if (checkWin(cells, size)) {
    status.innerText = currentPlayer + " wins!";
    gameOver = true;
    return;
  }
  if (checkDraw()) {
    status.innerText = "Draw!";
    gameOver = true;
    return;
  }
  currentPlayer = currentPlayer === "😎" ? "👽 " : "😎";
};

reset.addEventListener("click", () => {
  cells = [];
  init();
});

init();
